package com.projeto.integrado.dto;

public class RecursoIdNomeDTO {
	private Integer recursoId;
	private String recursoNome;

	public Integer getRecursoId() {
		return recursoId;
	}

	public void setRecursoId(Integer recursoId) {
		this.recursoId = recursoId;
	}

	public String getRecursoNome() {
		return recursoNome;
	}

	public void setRecursoNome(String recursoNome) {
		this.recursoNome = recursoNome;
	}
}