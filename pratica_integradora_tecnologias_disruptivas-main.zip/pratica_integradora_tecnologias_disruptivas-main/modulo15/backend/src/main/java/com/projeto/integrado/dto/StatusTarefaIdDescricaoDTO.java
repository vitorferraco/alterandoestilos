package com.projeto.integrado.dto;

public class StatusTarefaIdDescricaoDTO {
	private Integer statusTarefaId;
	private String statusDescricao;

	public Integer getStatusTarefaId() {
		return statusTarefaId;
	}

	public void setStatusTarefaId(Integer statusTarefaId) {
		this.statusTarefaId = statusTarefaId;
	}

	public String getStatusDescricao() {
		return statusDescricao;
	}

	public void setStatusDescricao(String statusDescricao) {
		this.statusDescricao = statusDescricao;
	}
}