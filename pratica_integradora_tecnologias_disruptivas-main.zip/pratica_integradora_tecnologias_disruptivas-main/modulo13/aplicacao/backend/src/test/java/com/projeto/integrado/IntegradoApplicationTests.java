package com.projeto.integrado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
