INSERT INTO categoria (categoria_id, categoria_nome) VALUES (1, 'Informática');
INSERT INTO categoria (categoria_id, categoria_nome) VALUES (2, 'Celulares');

INSERT INTO produto (produto_id, produto_nome, categoria_id) VALUES (1, 'Notebook DELL', 1);
INSERT INTO produto (produto_id, produto_nome, categoria_id) VALUES (2, 'Samsung Galaxy', 2);